// 🔒 SECRET CODE
function checkCode(){

let code =
document.getElementById("codeInput").value.trim();

if(code === "Happy birthday"){

document.getElementById("loginScreen").style.display="none";
document.getElementById("mainSite").style.display="block";

startStars();
startParty();

}else{

document.getElementById("error").innerText="❌ Wrong Code";

}

}

// 💌 OPEN LETTER
function openLetter(){

document.getElementById("letter").style.display="block";

startTyping();
startParty();

}

// 💖 FULL LONG MESSAGE (UNCHANGED STYLE)
const message = `Happy Birthday, Meri Pyari Gudiya 💖

Aaj ka din mere liye bhi utna hi special hai jitna tumhare liye,
kyunki aaj us insaan ka birthday hai jo meri life ko aur bhi khoobsurat bana deta hai.

Pata hai, jab bhi tumhari yaad aati hai na,
to bina kisi wajah ke bhi chehre par smile aa jati hai.

Tumhari baatein, tumhari hasi,
aur tumhara hona hi mere liye bahut special hai 🌸✨

Main dil se ye dua karta hu ki tumhari zindagi
hamesha khushiyon se bhari rahe.

Tum jo bhi sapne dekho,
wo poore ho.

Main hamesha tumhare saath rahunga,
tumhari khushiyon me bhi aur mushkil waqt me bhi 💖

Chahe zindagi hume kisi bhi mod par le jaye,
meri care aur support hamesha tumhare saath rahega ❤️

Tum bahut special ho,
aur hamesha rahogi 🌷

Kabhi kabhi kuch log zindagi me aise aa jate hain
jo dheere dheere bahut important ban jate hain.

Tum mere liye unhi logon me se ek ho 💕

Aaj tumhare birthday par bas itna kehna hai ki
tum hamesha khush raho, safe raho,
aur duniya ki har khushi tumhe mile ✨

Happy Birthday Once Again Gudiya 🎂💖

— Tumhara, Kunal 🌹`;

// TYPEWRITER
function startTyping(){

let i=0;
let box=document.getElementById("typewriter");

box.innerHTML="";

function type(){

if(i<message.length){

box.innerHTML += message.charAt(i);
i++;

setTimeout(type,20);

}

}

type();

}

// 💖 RANDOM HEARTS
document.addEventListener("click",(e)=>{

let hearts=["💖","💕","💗","💘","💞"];

let h=document.createElement("div");

h.className="heart";
h.innerHTML=hearts[Math.floor(Math.random()*hearts.length)];

h.style.left=e.clientX+"px";
h.style.top=e.clientY+"px";

document.body.appendChild(h);

setTimeout(()=>h.remove(),1000);

});

// 🎉 PARTY EFFECT
function startParty(){

for(let i=0;i<50;i++){

let c=document.createElement("div");
c.className="confetti";

c.style.left=Math.random()*100+"vw";
c.style.backgroundColor=`hsl(${Math.random()*360},100%,60%)`;

document.body.appendChild(c);

setTimeout(()=>c.remove(),3000);

}

document.body.classList.add("party-glow");

setTimeout(()=>{
document.body.classList.remove("party-glow");
},1500);

}

// ⭐ STARS
function startStars(){

const stars=document.querySelector(".stars");

for(let i=0;i<70;i++){

let s=document.createElement("div");
s.innerHTML="✨";
s.style.position="absolute";
s.style.left=Math.random()*100+"%";
s.style.top=Math.random()*100+"%";
s.style.fontSize=(10+Math.random()*15)+"px";

stars.appendChild(s);

}

}

// 🎁 GIFT
document.getElementById("giftBtn").addEventListener("click",()=>{

let g=document.getElementById("giftBox");

g.style.display = g.style.display==="block" ? "none" : "block";

});